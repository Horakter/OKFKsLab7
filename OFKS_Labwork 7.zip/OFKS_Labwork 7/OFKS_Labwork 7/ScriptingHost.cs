﻿using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace OFKS_Labwork_7
{
    public class ScriptingHost
    {
        private ScriptOptions _scriptOptions;
        private bool _isRunning;
        private Automation _automation;
        private EventService _eventService;

        public ScriptingHost(EventService eventService)
        {
            _eventService = eventService;
            _automation = new Automation(eventService);
            _scriptOptions = ScriptOptions.Default
                .WithReferences(AppDomain.CurrentDomain.GetAssemblies())
                .WithImports("System", "System.Collections.Generic", "System.Linq", "System.Windows", "OFKS_Labwork_7");
        }

        public async Task ExecuteAsync(string code)
        {
            try
            {
                await CSharpScript.EvaluateAsync(code, _scriptOptions, _automation);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка выполнения скрипта: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task ExecuteFromFileAsync(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show($"Файл не найден: {filePath}", "Ошибка",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string scriptCode = await File.ReadAllTextAsync(filePath);
                await ExecuteAsync(scriptCode);
                MessageBox.Show($"Скрипт из файла {Path.GetFileName(filePath)} выполнен успешно", "Успех",
                              MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки скрипта из файла: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task Run()
        {
            _isRunning = true;

            while (_isRunning)
            {
                try
                {
                    using (NamedPipeServerStream server = new NamedPipeServerStream("mypipe", PipeDirection.In))
                    {
                        await Task.Run(() => server.WaitForConnection());
                        await HandleClient(server);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Ошибка канала: {ex.Message}");
                }
            }
        }

        public void Stop()
        {
            _isRunning = false;
        }

        private async Task HandleClient(NamedPipeServerStream server)
        {
            try
            {
                using (StreamReader reader = new StreamReader(server))
                {
                    string command;
                    while ((command = await reader.ReadLineAsync()) != null)
                    {
                        await ProcessCommand(command.Trim());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обработки клиента: {ex.Message}", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task ProcessCommand(string command)
        {
            if (string.IsNullOrWhiteSpace(command))
                return;

            try
            {
                if (command.StartsWith("EXECUTE:"))
                {
                    string script = command.Substring(8);
                    await ExecuteAsync(script);
                }
                else if (command.StartsWith("FILE:"))
                {
                    string filePath = command.Substring(5);
                    await ExecuteFromFileAsync(filePath);
                }
                else if (command == "TEST")
                {
                    await ExecuteAsync("Message(\"Тестовая команда из канала!\");");
                }
                else if (command == "HELP")
                {
                    string helpMessage = "Доступные команды:\n" +
                                       "EXECUTE:<код> - выполнить C# код\n" +
                                       "FILE:<путь> - выполнить скрипт из файла\n" +
                                       "TEST - тестовая команда\n" +
                                       "HELP - справка\n" +
                                       "EXIT - завершить работу";
                    await ExecuteAsync($"Message(\"{helpMessage}\");");
                }
                else if (command == "EXIT")
                {
                    Stop();
                }
                else
                {
                    await ExecuteAsync(command);
                }
            }
            catch (Exception ex)
            {
                await ExecuteAsync($"Message(\"Ошибка команды: {ex.Message}\");");
            }
        }
    }
}