﻿using System.Windows;

namespace OFKS_Labwork_7
{
    public class Automation
    {
        private EventService _eventService;

        public Automation(EventService eventService)
        {
            _eventService = eventService;
        }

        // Базовые методы
        public void Message(string str)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                MessageBox.Show(str, "Сообщение из скрипта",
                              MessageBoxButton.OK, MessageBoxImage.Information);
            });
        }

        public void Log(string message)
        {
            System.Diagnostics.Debug.WriteLine($"[AUTOMATION] {DateTime.Now:HH:mm:ss}: {message}");
        }

        // CRUD
        public void AddEvent(string title, string description, DateTime eventDate)
        {
            var newEvent = new EventModel
            {
                Title = title,
                Description = description,
                EventDate = eventDate
            };
            _eventService.AddEvent(newEvent);
            Message($"Событие добавлено: {title}");
        }

        public void UpdateEvent(Guid id, string title, string description, DateTime eventDate, bool isCompleted)
        {
            var updatedEvent = new EventModel
            {
                Id = id,
                Title = title,
                Description = description,
                EventDate = eventDate,
                IsCompleted = isCompleted
            };
            _eventService.UpdateEvent(id, updatedEvent);
            Message($"Событие обновлено: {title}");
        }

        public void DeleteEvent(Guid id)
        {
            var eventToDelete = _eventService.GetEvent(id);
            if (eventToDelete != null)
            {
                _eventService.DeleteEvent(id);
                Message($"Событие удалено: {eventToDelete.Title}");
            }
            else
            {
                Message("Событие не найдено");
            }
        }

        public void MarkEventCompleted(Guid id)
        {
            var eventToUpdate = _eventService.GetEvent(id);
            if (eventToUpdate != null)
            {
                eventToUpdate.IsCompleted = true;
                _eventService.UpdateEvent(id, eventToUpdate);
                Message($"Событие завершено: {eventToUpdate.Title}");
            }
        }

        public void ListAllEvents()
        {
            var events = _eventService.GetEvents();
            if (!events.Any())
            {
                Message("Нет событий");
                return;
            }

            string eventList = "Все события:\n" + string.Join("\n", events.Select(e =>
                $"{e.EventDate:dd.MM.yyyy HH:mm} - {e.Title} {(e.IsCompleted ? "✓" : "")}"));
            Message(eventList);
        }

        public void ListUpcomingEvents()
        {
            var events = _eventService.GetUpcomingEvents();
            if (!events.Any())
            {
                Message("Нет предстоящих событий");
                return;
            }

            string eventList = "Предстоящие события:\n" + string.Join("\n", events.Select(e =>
                $"{e.EventDate:dd.MM.yyyy HH:mm} - {e.Title}"));
            Message(eventList);
        }

        public int Add(int a, int b) => a + b;

        public string ReverseString(string input)
        {
            char[] charArray = input.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public double CalculateCircleArea(double radius) => Math.PI * radius * radius;

        public DateTime ParseDateTime(string dateString)
        {
            return DateTime.Parse(dateString);
        }

        public Guid ParseGuid(string guidString)
        {
            return Guid.Parse(guidString);
        }
    }
}