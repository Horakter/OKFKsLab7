﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.IO;

namespace OFKS_Labwork_7
{
    public partial class MainWindow : Window
    {
        private ScriptingHost _scriptingHost;
        private Task _pipeTask;
        private EventService _eventService;
        private EventModel _selectedEvent;

        public MainWindow()
        {
            InitializeComponent();
            _eventService = new EventService();
            _scriptingHost = new ScriptingHost(_eventService);
            EventsListBox.ItemsSource = _eventService.GetEvents();
            StartPipeServer();
        }

        private void StartPipeServer()
        {
            _pipeTask = Task.Run(async () =>
            {
                await _scriptingHost.Run();
            });
        }

        // Обработчики для событий
        private void AddEventButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(EventTitleTextBox.Text))
                {
                    MessageBox.Show("Введите название события", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (EventDatePicker.SelectedDate == null)
                {
                    MessageBox.Show("Выберите дату события", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var newEvent = new EventModel
                {
                    Title = EventTitleTextBox.Text,
                    Description = EventDescriptionTextBox.Text,
                    EventDate = EventDatePicker.SelectedDate.Value
                };

                _eventService.AddEvent(newEvent);

                // Очистка полей
                EventTitleTextBox.Text = "Название события";
                EventDescriptionTextBox.Text = "Описание";
                EventDatePicker.SelectedDate = DateTime.Now;

                StatusText.Text = $"Событие '{newEvent.Title}' добавлено";
                StatusText.Foreground = System.Windows.Media.Brushes.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении события: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearEventsButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите удалить все события?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                _eventService.ClearAllEvents();
                StatusText.Text = "Все события удалены";
                StatusText.Foreground = System.Windows.Media.Brushes.Orange;
            }
        }

        private void EventsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedEvent = EventsListBox.SelectedItem as EventModel;
            if (_selectedEvent != null)
            {
                EventTitleTextBox.Text = _selectedEvent.Title;
                EventDescriptionTextBox.Text = _selectedEvent.Description;
                EventDatePicker.SelectedDate = _selectedEvent.EventDate;
            }
        }

        private void EventCompletedCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.DataContext is EventModel eventModel)
            {
                eventModel.IsCompleted = checkBox.IsChecked ?? false;
                _eventService.UpdateEvent(eventModel.Id, eventModel);

                StatusText.Text = $"Событие '{eventModel.Title}' отмечено как {(eventModel.IsCompleted ? "завершенное" : "незавершенное")}";
                StatusText.Foreground = eventModel.IsCompleted ?
                    System.Windows.Media.Brushes.Green : System.Windows.Media.Brushes.Blue;
            }
        }

        // Обработчики для скриптов
        private async void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            await ExecuteScriptAsync();
        }

        private async Task ExecuteScriptAsync()
        {
            string code = ScriptTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Введите код скрипта для выполнения", "Ошибка",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ExecuteButton.IsEnabled = false;
            StatusText.Text = "Выполнение скрипта...";
            StatusText.Foreground = System.Windows.Media.Brushes.Blue;

            try
            {
                await _scriptingHost.ExecuteAsync(code);
                StatusText.Text = "Скрипт выполнен успешно!";
                StatusText.Foreground = System.Windows.Media.Brushes.Green;
            }
            catch (System.Exception ex)
            {
                StatusText.Text = $"Ошибка выполнения: {ex.Message}";
                StatusText.Foreground = System.Windows.Media.Brushes.Red;
            }
            finally
            {
                ExecuteButton.IsEnabled = true;
            }
        }

        private async void ExecuteFromFileButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "C# скрипты (*.cs)|*.cs|Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*",
                Title = "Выберите файл скрипта"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    StatusText.Text = "Загрузка скрипта из файла...";
                    StatusText.Foreground = System.Windows.Media.Brushes.Blue;

                    await _scriptingHost.ExecuteFromFileAsync(openFileDialog.FileName);

                    // Загружаем содержимое файла в TextBox для просмотра
                    ScriptTextBox.Text = await File.ReadAllTextAsync(openFileDialog.FileName);

                    StatusText.Text = $"Скрипт из файла '{Path.GetFileName(openFileDialog.FileName)}' выполнен успешно";
                    StatusText.Foreground = System.Windows.Media.Brushes.Green;
                }
                catch (Exception ex)
                {
                    StatusText.Text = $"Ошибка: {ex.Message}";
                    StatusText.Foreground = System.Windows.Media.Brushes.Red;
                }
            }
        }

        private void CreateSampleScriptButton_Click(object sender, RoutedEventArgs e)
        {
            string sampleScript = @"// Пример скрипта для управления событиями
using System;
using System.Linq;

// 1. Добавление событий
Message(""Добавляю тестовые события..."");
AddEvent(""Встреча с командой"", ""Еженедельная встреча разработчиков"", DateTime.Now.AddDays(1));
AddEvent(""Дедлайн проекта"", ""Сдача лабораторной работы"", DateTime.Now.AddDays(3));
AddEvent(""Совещание"", ""Обсуждение планов на следующий месяц"", DateTime.Now.AddHours(6));

// 2. Вывод всех событий
Message(""Список всех событий:"");
ListAllEvents();

// 3. Математические операции
int sum = Add(5, 3);
Message($""5 + 3 = {sum}"");

// 4. Работа со строками
string reversed = ReverseString(""Hello World!"");
Message($""Обратная строка: {reversed}"");

// 5. Вычисление площади круга
double area = CalculateCircleArea(5);
Message($""Площадь круга с радиусом 5: {area:F2}"");

// 6. Фильтрация предстоящих событий
Message(""Предстоящие события:"");
ListUpcomingEvents();

Log(""Пример скрипта выполнен успешно!"");
";

            ScriptTextBox.Text = sampleScript;
            StatusText.Text = "Создан пример скрипта. Нажмите 'Выполнить скрипт' для запуска.";
            StatusText.Foreground = System.Windows.Media.Brushes.Blue;
        }

        private void AddTestEventsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Добавляем тестовые события
                var testEvents = new[]
                {
                    new EventModel
                    {
                        Title = "Тестовая встреча",
                        Description = "Это тестовое событие для демонстрации",
                        EventDate = DateTime.Now.AddHours(2)
                    },
                    new EventModel
                    {
                        Title = "Важная задача",
                        Description = "Необходимо выполнить до конца дня",
                        EventDate = DateTime.Now.AddDays(1)
                    },
                    new EventModel
                    {
                        Title = "Прошедшее событие",
                        Description = "Событие, которое уже прошло",
                        EventDate = DateTime.Now.AddDays(-1),
                        IsCompleted = true
                    },
                    new EventModel
                    {
                        Title = "Планерка",
                        Description = "Ежедневное собрание команды",
                        EventDate = DateTime.Now.AddHours(24)
                    }
                };

                foreach (var ev in testEvents)
                {
                    _eventService.AddEvent(ev);
                }

                StatusText.Text = "Добавлено 4 тестовых события";
                StatusText.Foreground = System.Windows.Media.Brushes.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении тестовых событий: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ShowAllEventsButton_Click(object sender, RoutedEventArgs e)
        {
            var events = _eventService.GetEvents();
            if (!events.Any())
            {
                StatusText.Text = "Нет событий для отображения";
                StatusText.Foreground = System.Windows.Media.Brushes.Orange;
                return;
            }

            string message = $"Всего событий: {events.Count}\n";
            message += string.Join("\n", events.Select(ev =>
                $"{ev.EventDate:dd.MM.yyyy HH:mm} - {ev.Title} {(ev.IsCompleted ? "✓" : "")}"));

            MessageBox.Show(message, "Все события",
                MessageBoxButton.OK, MessageBoxImage.Information);

            StatusText.Text = "Показаны все события";
            StatusText.Foreground = System.Windows.Media.Brushes.Blue;
        }

        private void ShowUpcomingEventsButton_Click(object sender, RoutedEventArgs e)
        {
            var upcomingEvents = _eventService.GetUpcomingEvents();
            if (!upcomingEvents.Any())
            {
                StatusText.Text = "Нет предстоящих событий";
                StatusText.Foreground = System.Windows.Media.Brushes.Orange;
                return;
            }

            string message = $"Предстоящих событий: {upcomingEvents.Count}\n";
            message += string.Join("\n", upcomingEvents.Select(ev =>
                $"{ev.EventDate:dd.MM.yyyy HH:mm} - {ev.Title}"));

            MessageBox.Show(message, "Предстоящие события",
                MessageBoxButton.OK, MessageBoxImage.Information);

            StatusText.Text = "Показаны предстоящие события";
            StatusText.Foreground = System.Windows.Media.Brushes.Blue;
        }

        // Обработчик для кнопки, который уже был (можно оставить или удалить)
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Оставьте пустым или добавьте общую логику
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            _scriptingHost.Stop();
            _pipeTask?.Wait(1000);
            base.OnClosing(e);
        }
    }
}