﻿namespace OFKS_Labwork_7
{
    public class EventModel
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime EventDate { get; set; } = DateTime.Now;
        public bool IsCompleted { get; set; } = false;

        public override string ToString()
        {
            return $"{EventDate:dd.MM.yyyy HH:mm} - {Title} {(IsCompleted ? "✓" : "")}";
        }
    }
}