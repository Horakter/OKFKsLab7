﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace OFKS_Labwork_7
{
    public class EventService
    {
        private ObservableCollection<EventModel> _events;

        public EventService()
        {
            _events = new ObservableCollection<EventModel>();
        }

        public ObservableCollection<EventModel> GetEvents() => _events;

        public void AddEvent(EventModel eventModel)
        {
            _events.Add(eventModel);
        }

        public void UpdateEvent(Guid id, EventModel updatedEvent)
        {
            var existingEvent = _events.FirstOrDefault(e => e.Id == id);
            if (existingEvent != null)
            {
                existingEvent.Title = updatedEvent.Title;
                existingEvent.Description = updatedEvent.Description;
                existingEvent.EventDate = updatedEvent.EventDate;
                existingEvent.IsCompleted = updatedEvent.IsCompleted;
            }
        }

        public void DeleteEvent(Guid id)
        {
            var eventToDelete = _events.FirstOrDefault(e => e.Id == id);
            if (eventToDelete != null)
            {
                _events.Remove(eventToDelete);
            }
        }

        public EventModel GetEvent(Guid id)
        {
            return _events.FirstOrDefault(e => e.Id == id);
        }

        public List<EventModel> GetUpcomingEvents()
        {
            return _events.Where(e => e.EventDate >= DateTime.Now && !e.IsCompleted)
                         .OrderBy(e => e.EventDate)
                         .ToList();
        }

        public List<EventModel> GetCompletedEvents()
        {
            return _events.Where(e => e.IsCompleted).ToList();
        }

        public void ClearAllEvents()
        {
            _events.Clear();
        }
    }
}